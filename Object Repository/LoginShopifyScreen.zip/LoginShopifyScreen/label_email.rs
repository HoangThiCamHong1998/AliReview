<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>label_email</name>
   <tag></tag>
   <elementGuidId>06bebf18-f14d-4d80-94dd-696d6ddd94b6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id=&quot;account_lookup&quot;]//child::label[@class=&quot;next-label&quot; and contains(text(), &quot;Email&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
