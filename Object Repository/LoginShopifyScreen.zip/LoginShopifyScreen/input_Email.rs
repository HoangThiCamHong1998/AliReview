<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>//input[@id=&quot;email_type_ahead&quot;]</description>
   <name>input_email</name>
   <tag></tag>
   <elementGuidId>4d004193-6017-4a3a-a181-7557e7b43f04</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@class=&quot;next-input combined-input-wrapper type-ahead-wrapper&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
