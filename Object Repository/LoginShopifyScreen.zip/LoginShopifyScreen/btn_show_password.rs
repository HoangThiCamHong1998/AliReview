<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_show_password</name>
   <tag></tag>
   <elementGuidId>3e8cd07a-8306-47d8-9870-43296457ca97</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@class=&quot;next-field__connected-wrapper ui-password next-input--stylized&quot;]//button[@class=&quot;ui-button ui-button--transparent ui-password__button js-password-button&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
