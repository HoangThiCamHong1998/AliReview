<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>label_password</name>
   <tag></tag>
   <elementGuidId>25fb1e9e-52c4-42eb-b88b-0af96628219f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id=&quot;account_lookup&quot;]//child::label[@class=&quot;next-label&quot; and contains(text(), &quot;Password&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
