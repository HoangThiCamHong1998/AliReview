<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>input_store_name</name>
   <tag></tag>
   <elementGuidId>a2ef95d5-c676-4209-af00-1bb7d936b9b5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[contains(text(), &quot;Store Name&quot;)]/parent::label/ancestor::div[@class=&quot;Polaris-Labelled__LabelWrapper&quot;]/following::div[@class=&quot;Polaris-Connected&quot;]//input[@class=&quot;Polaris-TextField__Input&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
