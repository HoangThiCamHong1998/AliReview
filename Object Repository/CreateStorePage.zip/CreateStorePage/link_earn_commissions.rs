<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>link_earn_commissions</name>
   <tag></tag>
   <elementGuidId>4c39e984-beca-4f04-a827-579230362788</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[@class=&quot;Polaris-Text--root Polaris-Text--subdued&quot;]/span/a[contains(text(),&quot;earn commissions&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
