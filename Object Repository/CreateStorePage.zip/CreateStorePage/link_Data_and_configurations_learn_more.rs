<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>link_data_and_configurations_learn_more</name>
   <tag></tag>
   <elementGuidId>35b043b4-e725-4427-9a7b-45e7cbd61243</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[@class=&quot;Polaris-RadioButton&quot;]//input[@value=&quot;STATIC_DATA&quot;]/ancestor::label/following::div//a[contains(text(), &quot;Learn more.&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
