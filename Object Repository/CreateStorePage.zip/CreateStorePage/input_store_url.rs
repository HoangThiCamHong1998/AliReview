<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>input_store_url</name>
   <tag></tag>
   <elementGuidId>f5a89c50-e5fa-45d1-80b9-e7ae9cb6e184</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[contains(text(), &quot;Store Name&quot;)]/parent::label/ancestor::div[@class=&quot;Polaris-Labelled__LabelWrapper&quot;]/following::div[@class=&quot;Polaris-Connected&quot;]//input[@class=&quot;Polaris-TextField__Input Polaris-TextField__Input--suffixed&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
