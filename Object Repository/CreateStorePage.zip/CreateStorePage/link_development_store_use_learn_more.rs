<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>link_development_store_use_learn_more</name>
   <tag></tag>
   <elementGuidId>afd2268b-87f6-4b72-9592-81a6818c1550</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@class=&quot;Polaris-Card__Header&quot;]//span[@class=&quot;Polaris-Text--root Polaris-Text--bodyMd Polaris-Text--subdued&quot;]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
